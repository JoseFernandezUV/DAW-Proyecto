package Modelo;
import java.io.Serializable;

public class Roles implements Serializable {
    private int ID;
    private String Rol;

    public Roles() {
        // Constructor vacío
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getRol() {
        return Rol;
    }

    public void setRol(String rol) {
        Rol = rol;
    }
}
