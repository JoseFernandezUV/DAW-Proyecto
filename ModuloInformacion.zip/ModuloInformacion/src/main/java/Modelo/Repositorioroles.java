package Modelo;

import java.io.Serializable;

public class Repositorioroles implements Serializable {
    private int fkidrepositorio;

    private int fkrolrepositorio;

    public Repositorioroles(){


    }

    public int getFkidrepositorio() {
        return fkidrepositorio;
    }

    public void setFkidrepositorio(int fkidrepositorio) {
        this.fkidrepositorio = fkidrepositorio;
    }

    public int getFkrolrepositorio() {
        return fkrolrepositorio;
    }

    public void setFkrolrepositorio(int fkrolrepositorio) {
        this.fkrolrepositorio = fkrolrepositorio;
    }
}
