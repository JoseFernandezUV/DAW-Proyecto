package Modelo;

import java.io.Serializable;

public class Rolesypermisos implements Serializable {

    public Rolesypermisos(){

    }
    private int Rol_id;

    private int Permiso_id;

    public int getRol_id() {
        return Rol_id;
    }

    public void setRol_id(int rol_id) {
        Rol_id = rol_id;
    }

    public int getPermiso_id() {
        return Permiso_id;
    }

    public void setPermiso_id(int permiso_id) {
        Permiso_id = permiso_id;
    }


}
