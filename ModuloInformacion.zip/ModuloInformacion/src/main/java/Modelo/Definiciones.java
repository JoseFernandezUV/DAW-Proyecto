package Modelo;
import java.io.Serializable;

public class Definiciones implements Serializable {
    private int ID;
    private String Termino;
    private String Definicion;

    private int Rol_FK;

    public Definiciones() {
        // Constructor vacío
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTermino() {
        return Termino;
    }

    public void setTermino(String termino) {
        Termino = termino;
    }

    public String getDefinicion() {
        return Definicion;
    }

    public void setDefinicion(String definicion) {
        Definicion = definicion;
    }

    public int getRol_FK() {
        return Rol_FK;
    }

    public void setRol_FK(int rol_FK) {
        Rol_FK = rol_FK;
    }
}
