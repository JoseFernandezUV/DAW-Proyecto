package Modelo;
import java.io.Serializable;
import java.util.Date;

public class Repositorio implements Serializable {
    private int ID;
    private String Titulo;
    private String Descripcion;

    private String URL;

    private String Fecha;

    private String FKTipo;

    private String FKUsuario;
    public Repositorio() {
        // Constructor vacío
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String titulo) {
        Titulo = titulo;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String fecha) {
        Fecha = fecha;
    }

    public String getFKTipo() {
        return FKTipo;
    }

    public void setFKTipo(String FKTipo) {
        this.FKTipo = FKTipo;
    }

    public String getFKUsuario() {
        return FKUsuario;
    }

    public void setFKUsuario(String FKUsuario) {
        this.FKUsuario = FKUsuario;
    }
}
