package Modelo;
import java.io.*;

public class Areas implements Serializable {
    private int ID;
    private String Area;

    public Areas(){


    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getArea() {
        return Area;
    }

    public void setArea(String area) {
        Area = area;
    }
}