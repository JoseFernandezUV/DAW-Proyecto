package Controlador;

import Datos.DirectorioDAO;
import Modelo.Directorio;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.logging.Logger;

public class DirectorioServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(DirectorioServlet.class.getName());
    private DirectorioDAO directorioDAO = new DirectorioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        // Mensaje de depuración para verificar la entrada al método doGet
        System.out.println("Entrando al método doGet del servlet.");
        LOGGER.info("Entrando al método doGet del servlet.");

        try (PrintWriter out = response.getWriter()) {
            List<Directorio> directorioList = directorioDAO.getAllDirectorio();

            if (directorioList == null || directorioList.isEmpty()) {
                out.println("No se encontraron registros en la base de datos.");
                LOGGER.info("No se encontraron registros en la base de datos.");
            } else {
                HttpSession sesion = request.getSession();
                sesion.setAttribute("directorioList", directorioList);
                LOGGER.info("Datos del directorio enviados a la JSP.");
                response.sendRedirect("Directorio.jsp"); // Asegúrate de que el nombre del archivo JSP es correcto y está en la carpeta correcta
            }
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.severe("Error al obtener los datos del directorio: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al obtener los datos del directorio");
        }
    }
}
