package Datos;

import Modelo.Definiciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DefinicionesDAO {
    private static final Logger LOGGER = Logger.getLogger(DefinicionesDAO.class.getName());
    private Conexion conexion = new Conexion();

    public List<Definiciones> getAllDefiniciones() {
        List<Definiciones> definicionesList = new ArrayList<>();
        String sql = "SELECT * FROM Definiciones";
        try (Connection con = conexion.establecerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            // Mensaje de depuración para verificar la conexión a la base de datos
            if (con != null) {
                LOGGER.info("Conexión a la base de datos establecida.");
            } else {
                LOGGER.severe("Error al establecer la conexión a la base de datos.");
            }

            // Mensaje de depuración para verificar la ejecución de la consulta
            LOGGER.info("Ejecutando consulta: " + sql);

            while (rs.next()) {
                Definiciones definicion = new Definiciones();
                definicion.setID(rs.getInt("ID"));
                definicion.setTermino(rs.getString("Termino"));
                definicion.setDefinicion(rs.getString("Definicion"));
                definicion.setRol_FK(rs.getInt("Rol_FK"));
                definicionesList.add(definicion);
                LOGGER.info("Registro recuperado: " + definicion.getTermino());
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al obtener definiciones", e);
        }
        return definicionesList;
    }
}
