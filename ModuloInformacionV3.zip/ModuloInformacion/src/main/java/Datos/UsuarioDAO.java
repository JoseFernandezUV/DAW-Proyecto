package Datos;

import Modelo.Usuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UsuarioDAO {
    private static final Logger LOGGER = Logger.getLogger(UsuarioDAO.class.getName());
    private Conexion conexion = new Conexion();

    public Usuarios validarUsuario(String nombre, String contraseña) {
        Usuarios usuario = null;
        String sql = "SELECT u.*, r.Rol FROM Usuario u " +
                "JOIN UsuarioRoles ur ON u.ID = ur.Usuario_id " +
                "JOIN Roles r ON ur.Rol_id = r.ID " +
                "WHERE u.Nombre = ? AND u.Contraseña = ?";
        try (Connection con = conexion.establecerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setString(2, contraseña);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    usuario = new Usuarios();
                    usuario.setID(rs.getInt("ID"));
                    usuario.setNombre(rs.getString("Nombre"));
                    usuario.setContraseña(rs.getString("Contraseña"));
                    usuario.setRol(rs.getString("Rol"));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al validar el usuario", e);
        }
        return usuario;
    }

    public String obtenerRol(int usuarioId) {
        String rol = null;
        String sql = "SELECT Roles.Rol FROM Roles " +
                "JOIN UsuarioRoles ON Roles.ID = UsuarioRoles.Rol_id " +
                "WHERE UsuarioRoles.Usuario_id = ?";
        try (Connection con = conexion.establecerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, usuarioId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    rol = rs.getString("Rol");
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al obtener el rol del usuario", e);
        }
        return rol;
    }
}
