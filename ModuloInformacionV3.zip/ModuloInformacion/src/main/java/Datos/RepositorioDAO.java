package Datos;

import Modelo.Repositorio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date; // Importar java.sql.Date
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RepositorioDAO {
    private static final Logger LOGGER = Logger.getLogger(RepositorioDAO.class.getName());
    private Conexion conexion = new Conexion();

    public List<Repositorio> getRepositorioPorRol(String rol) {
        List<Repositorio> repositorioList = new ArrayList<>();
        String sql = "SELECT Titulo, Descripcion, URL, Fecha FROM Repositorio WHERE ID IN (SELECT fkidrepositorio FROM Repositorioroles WHERE fkrolrepositorio = (SELECT ID FROM Roles WHERE Rol = ?))";

        try (Connection con = conexion.establecerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, rol);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Repositorio repositorio = new Repositorio();
                repositorio.setTitulo(rs.getString("Titulo"));
                repositorio.setDescripcion(rs.getString("Descripcion"));
                repositorio.setURL(rs.getString("URL"));
                repositorio.setFecha(rs.getString("Fecha"));
                repositorioList.add(repositorio);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al obtener datos del repositorio", e);
        }
        return repositorioList;
    }

    public void agregarRepositorio(Repositorio repositorio, List<Integer> roles) {
        String sqlRepositorio = "INSERT INTO Repositorio (Titulo, Descripcion, URL, Fecha, FKTipo, FKUsuario) VALUES (?, ?, ?, ?, ?, ?)";
        String sqlRepositorioRoles = "INSERT INTO Repositorioroles (fkidrepositorio, fkrolrepositorio) VALUES (?, ?)";

        try (Connection con = conexion.establecerConexion();
             PreparedStatement psRepositorio = con.prepareStatement(sqlRepositorio, PreparedStatement.RETURN_GENERATED_KEYS);
             PreparedStatement psRepositorioRoles = con.prepareStatement(sqlRepositorioRoles)) {

            psRepositorio.setString(1, repositorio.getTitulo());
            psRepositorio.setString(2, repositorio.getDescripcion());
            psRepositorio.setString(3, repositorio.getURL());
            psRepositorio.setDate(4, Date.valueOf(repositorio.getFecha())); // Convertir String a Date
            psRepositorio.setInt(5, repositorio.getFKTipo());
            psRepositorio.setInt(6, repositorio.getFKUsuario());
            psRepositorio.executeUpdate();

            // Obtener el ID generado para el repositorio
            ResultSet generatedKeys = psRepositorio.getGeneratedKeys();
            if (generatedKeys.next()) {
                int repositorioId = generatedKeys.getInt(1);

                // Insertar en la tabla Repositorioroles para cada rol
                for (Integer rolId : roles) {
                    psRepositorioRoles.setInt(1, repositorioId);
                    psRepositorioRoles.setInt(2, rolId);
                    psRepositorioRoles.executeUpdate();
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al agregar repositorio", e);
        }
    }
}
