package Modelo;

import Datos.Conexion;
//Clase para probar la conexión
public class test {
    public static void main(String[] args) {
        Conexion objetoConexion = new Conexion();
        objetoConexion.establecerConexion();

    }
}
