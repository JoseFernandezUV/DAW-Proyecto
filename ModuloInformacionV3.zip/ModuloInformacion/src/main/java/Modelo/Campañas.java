package Modelo;
import java.io.Serializable;

public class Campañas implements Serializable {
    private int ID;
    private String Nombre;
    private int AreaFK;
    private int NivelFK;

    private String Descripcion;
    private String Area;

    private String Nivel;

    public Campañas() {
        // Constructor vacío
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public int getAreaFK() {
        return AreaFK;
    }

    public void setAreaFK(int areaFK) {
        AreaFK = areaFK;
    }

    public int getNivelFK() {
        return NivelFK;
    }

    public void setNivelFK(int nivelFK) {
        NivelFK = nivelFK;
    }

    public String getArea() {
        return Area;
    }

    public void setArea(String area) {
        Area = area;
    }

    public String getNivel() {
        return Nivel;
    }

    public void setNivel(String nivel) {
        Nivel = nivel;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }
}


