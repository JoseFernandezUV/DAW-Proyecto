package Modelo;
import java.io.Serializable;

public class Niveles implements Serializable {
    private int ID;
    private String Nivel;

    public Niveles() {
        // Constructor vacío
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNivel() {
        return Nivel;
    }

    public void setNivel(String nivel) {
        Nivel = nivel;
    }
}
