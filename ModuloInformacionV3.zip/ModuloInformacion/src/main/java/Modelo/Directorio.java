package Modelo;
import java.io.Serializable;

public class Directorio implements Serializable {
    private int ID;
    private String Nombre;
    private String Telefono;
    private String Correo;
    private String Ubicacion;
    private String FKPuesto;

    private String Puesto;

    public Directorio() {
        // Constructor vacío
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String telefono) {
        Telefono = telefono;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }

    public String getUbicacion() {
        return Ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        Ubicacion = ubicacion;
    }

    public String getFKPuesto() {
        return FKPuesto;
    }

    public void setFKPuesto(String FKPuesto) {
        this.FKPuesto = FKPuesto;
    }

    public String getPuesto() {
        return Puesto;
    }

    public void setPuesto(String puesto) {
        Puesto = puesto;
    }
}
