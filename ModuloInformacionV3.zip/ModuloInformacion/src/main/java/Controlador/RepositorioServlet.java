package Controlador;

import Datos.RepositorioDAO;
import Modelo.Repositorio;
import Modelo.Usuarios;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.logging.Logger;

public class RepositorioServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(RepositorioServlet.class.getName());
    private RepositorioDAO repositorioDAO = new RepositorioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        LOGGER.info("Entrando al método doGet del servlet de repositorio.");

        try {
            HttpSession session = request.getSession();
            String rol = (String) session.getAttribute("rol");

            List<Repositorio> repositorioList = repositorioDAO.getRepositorioPorRol(rol);
            session.setAttribute("repositorioList", repositorioList);

            response.sendRedirect("Repositorio.jsp"); // Redirige a Repositorio.jsp
        } catch (Exception e) {
            LOGGER.severe("Error al obtener los datos del repositorio: " + e.getMessage());
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al obtener los datos del repositorio");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String titulo = request.getParameter("titulo");
        String descripcion = request.getParameter("descripcion");
        String url = request.getParameter("url");
        String fecha = request.getParameter("fecha");
        int fkTipo = Integer.parseInt(request.getParameter("fkTipo"));
        HttpSession session = request.getSession();
        Usuarios usuario = (Usuarios) session.getAttribute("usuario");
        int fkUsuario = usuario.getID();

        Repositorio repositorio = new Repositorio();
        repositorio.setTitulo(titulo);
        repositorio.setDescripcion(descripcion);
        repositorio.setURL(url);
        repositorio.setFecha(fecha);  // Almacenar fecha como String
        repositorio.setFKTipo(fkTipo);
        repositorio.setFKUsuario(fkUsuario);

        String[] rolesSeleccionados = request.getParameterValues("roles");
        List<Integer> roles = new ArrayList<>();
        for (String rol : rolesSeleccionados) {
            roles.add(Integer.parseInt(rol));
        }

        repositorioDAO.agregarRepositorio(repositorio, roles);

        response.sendRedirect("repositorio"); // Redirige a la página del repositorio
    }
}
