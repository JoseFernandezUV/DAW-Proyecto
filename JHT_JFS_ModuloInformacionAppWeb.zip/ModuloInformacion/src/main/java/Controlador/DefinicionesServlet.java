package Controlador;

import Datos.DefinicionesDAO;
import Modelo.Definiciones;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.logging.Logger;

public class DefinicionesServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(DefinicionesServlet.class.getName());
    private DefinicionesDAO definicionesDAO = new DefinicionesDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOGGER.info("Entrando al método doGet del servlet de definiciones.");

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");


        try {
            List<Definiciones> definicionesList = definicionesDAO.getAllDefiniciones();

            HttpSession session = request.getSession();
            session.setAttribute("definicionesList", definicionesList);

            response.sendRedirect("Definiciones.jsp"); // Redirige a Definiciones.jsp
        } catch (Exception e) {
            LOGGER.severe("Error al obtener los datos de las definiciones: " + e.getMessage());
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al obtener los datos de las definiciones");
        }
    }
}
