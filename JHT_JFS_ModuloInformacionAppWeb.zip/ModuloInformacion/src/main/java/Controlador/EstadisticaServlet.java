package Controlador;

import Datos.EstadisticasDAO;
import Modelo.Estadisticas;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.logging.Logger;

public class EstadisticaServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(EstadisticaServlet.class.getName());
    private EstadisticasDAO estadisticasDAO = new EstadisticasDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOGGER.info("Entrando al método doGet del servlet de estadísticas.");

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");


        try {
            List<Estadisticas> estadisticasList = estadisticasDAO.getAllEstadisticas();

            HttpSession session = request.getSession();
            session.setAttribute("estadisticasList", estadisticasList);

            response.sendRedirect("Estadistica.jsp"); // Redirige a Estadistica.jsp
        } catch (Exception e) {
            LOGGER.severe("Error al obtener los datos de las estadísticas: " + e.getMessage());
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al obtener los datos de las estadísticas");
        }
    }
}
