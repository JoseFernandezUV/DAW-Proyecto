package Controlador;

import Datos.UsuarioDAO;
import Modelo.Usuarios;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.logging.Logger;

public class LoginServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(LoginServlet.class.getName());
    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String nombre = request.getParameter("username");
        String contraseña = request.getParameter("password");

        Usuarios usuario = usuarioDAO.validarUsuario(nombre, contraseña);
        if (usuario != null && usuario.getContraseña().equals(contraseña)) {
            HttpSession session = request.getSession();
            session.setAttribute("usuario", usuario);

            // Obtener el rol del usuario
            String rol = usuarioDAO.obtenerRol(usuario.getID());
            session.setAttribute("rol", rol);

            response.sendRedirect("index.jsp"); // Redirige a index.jsp
        } else {
            request.setAttribute("error", "Usuario o contraseña incorrectos");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
