package Controlador;

import Datos.CampañaDAO;
import Modelo.Campañas;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.logging.Logger;

public class CampanaServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(CampanaServlet.class.getName());
    private CampañaDAO campañaDAO = new CampañaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOGGER.info("Entrando al método doGet del servlet de campañas.");
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");


        try {
            List<Campañas> campañasList = campañaDAO.getAllCampañas();

            HttpSession session = request.getSession();
            session.setAttribute("campañasList", campañasList);

            response.sendRedirect("Campanas.jsp"); // Redirige a Campanas.jsp
        } catch (Exception e) {
            LOGGER.severe("Error al obtener los datos de las campañas: " + e.getMessage());
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al obtener los datos de las campañas");
        }
    }
}
