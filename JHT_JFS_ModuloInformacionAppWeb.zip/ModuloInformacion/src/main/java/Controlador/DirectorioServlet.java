package Controlador;

import Datos.DirectorioDAO;
import Modelo.Directorio;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.logging.Logger;

public class DirectorioServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(DirectorioServlet.class.getName());
    private DirectorioDAO directorioDAO = new DirectorioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        LOGGER.info("Entrando al método doGet del servlet.");

        try {
            List<Directorio> directorioList = directorioDAO.getAllDirectorio();
            JSONArray jsonArray = new JSONArray();
            for (Directorio directorio : directorioList) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("Nombre", directorio.getNombre());
                jsonObject.put("Telefono", directorio.getTelefono());
                jsonObject.put("Correo", directorio.getCorreo());
                jsonObject.put("Ubicacion", directorio.getUbicacion());
                jsonObject.put("Puesto", directorio.getPuesto());
                jsonArray.put(jsonObject);
            }

            HttpSession session = request.getSession();
            session.setAttribute("directorioList", jsonArray.toString());
            LOGGER.info("Datos del directorio enviados a la JSP.");
            response.sendRedirect("Directorio.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.severe("Error al obtener los datos del directorio: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al obtener los datos del directorio");
        }
    }
}
