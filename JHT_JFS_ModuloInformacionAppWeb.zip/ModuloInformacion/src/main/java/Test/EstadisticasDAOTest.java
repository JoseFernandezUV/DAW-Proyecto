package Test;

import Datos.EstadisticasDAO;
import Modelo.Estadisticas;

import java.util.List;

public class EstadisticasDAOTest {

    public static void main(String[] args) {

        EstadisticasDAO estadisticasDAO = new EstadisticasDAO();


        List<Estadisticas> estadisticasList = estadisticasDAO.getAllEstadisticas();


        if (estadisticasList != null && !estadisticasList.isEmpty()) {
            System.out.println("Datos de las estadísticas:");
            for (Estadisticas estadisticas : estadisticasList) {
                System.out.println("Área: " + estadisticas.getArea());
                System.out.println("Nivel: " + estadisticas.getNivel());
                System.out.println("Lugar: " + estadisticas.getLugar());
                System.out.println("Fecha: " + estadisticas.getFecha());
                System.out.println("Datos: " + estadisticas.getDatos());
                System.out.println("Descripción: " + estadisticas.getDescripcion());
                System.out.println("------");
            }
        } else {
            System.out.println("No se encontraron datos de estadísticas.");
        }
    }
}
