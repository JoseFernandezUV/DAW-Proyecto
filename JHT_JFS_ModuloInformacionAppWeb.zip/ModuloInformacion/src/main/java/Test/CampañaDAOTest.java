package Test;

import Datos.CampañaDAO;
import Modelo.Campañas;

import java.util.List;

public class CampañaDAOTest {

    public static void main(String[] args) {

        CampañaDAO campañaDAO = new CampañaDAO();


        List<Campañas> campañasList = campañaDAO.getAllCampañas();


        if (campañasList != null && !campañasList.isEmpty()) {
            System.out.println("Datos de las campañas:");
            for (Campañas campañas : campañasList) {
                System.out.println("ID: " + campañas.getID());
                System.out.println("Nombre: " + campañas.getNombre());
                System.out.println("Area: " + campañas.getArea());
                System.out.println("Nivel: " + campañas.getNivel());
                System.out.println("------");
            }
        } else {
            System.out.println("No se encontraron datos de campañas.");
        }
    }
}
