package Test;

import Datos.DirectorioDAO;
import Modelo.Directorio;

import java.util.List;

public class DirectorioDAOTest {

    public static void main(String[] args) {

        DirectorioDAO directorioDAO = new DirectorioDAO();


        List<Directorio> directorioList = directorioDAO.getAllDirectorio();


        if (directorioList != null && !directorioList.isEmpty()) {
            System.out.println("Datos del directorio:");
            for (Directorio directorio : directorioList) {
                System.out.println("Nombre: " + directorio.getNombre());
                System.out.println("Teléfono: " + directorio.getTelefono());
                System.out.println("Correo: " + directorio.getCorreo());
                System.out.println("Ubicación: " + directorio.getUbicacion());
                System.out.println("Puesto: " + directorio.getPuesto());
                System.out.println("------");
            }
        } else {
            System.out.println("No se encontraron datos del directorio.");
        }
    }
}
