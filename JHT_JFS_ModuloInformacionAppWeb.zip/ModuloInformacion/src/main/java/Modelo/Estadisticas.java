package Modelo;
import java.io.Serializable;
import java.util.Date;

public class Estadisticas implements Serializable {
    private int ID;

    private String Area;

    private String Nivel;
    private int FKArea;
    private int FKNivel;
    private String Lugar;
    private Date Fecha;
    private float Datos;
    private String Descripcion;
    private int FKPermiso;

    public Estadisticas() {
        // Constructor vacío
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getFKArea() {
        return FKArea;
    }

    public void setFKArea(int FKArea) {
        this.FKArea = FKArea;
    }

    public int getFKNivel() {
        return FKNivel;
    }

    public void setFKNivel(int FKNivel) {
        this.FKNivel = FKNivel;
    }

    public String getLugar() {
        return Lugar;
    }

    public void setLugar(String lugar) {
        Lugar = lugar;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date fecha) {
        Fecha = fecha;
    }

    public float getDatos() {
        return Datos;
    }

    public void setDatos(float datos) {
        Datos = datos;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public int getFKPermiso() {
        return FKPermiso;
    }

    public void setFKPermiso(int FKPermiso) {
        this.FKPermiso = FKPermiso;
    }

    public String getArea() {
        return Area;
    }

    public void setArea(String area) {
        Area = area;
    }

    public String getNivel() {
        return Nivel;
    }

    public void setNivel(String nivel) {
        Nivel = nivel;
    }
}
