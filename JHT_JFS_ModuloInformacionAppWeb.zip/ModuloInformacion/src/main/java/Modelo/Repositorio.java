package Modelo;
import java.io.Serializable;
import java.sql.Date;

public class Repositorio implements Serializable {
    private int ID;
    private String Titulo;
    private String Descripcion;

    private String url;

    private String URL;

    private String Fecha;


    private int FKTipo;

    private int FKUsuario;
    public Repositorio() {
        // Constructor vacío
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String titulo) {
        Titulo = titulo;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }



    public int getFKTipo() {
        return FKTipo;
    }

    public void setFKTipo(int FKTipo) {
        this.FKTipo = FKTipo;
    }

    public int getFKUsuario() {
        return FKUsuario;
    }

    public void setFKUsuario(int FKUsuario) {
        this.FKUsuario = FKUsuario;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String fecha) {
        Fecha = fecha;
    }
}
