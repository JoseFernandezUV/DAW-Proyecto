package Modelo;

import java.io.Serializable;

public class RedesSociales implements Serializable {
    private String Entidad;

    private String Telefono;

    private String Correo;

    private String Facebook;

    private String Instagra;

    private String Direccion;

    public RedesSociales(){

    }

    public String getEntidad() {
        return Entidad;
    }

    public void setEntidad(String entidad) {
        Entidad = entidad;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String telefono) {
        Telefono = telefono;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }

    public String getFacebook() {
        return Facebook;
    }

    public void setFacebook(String facebook) {
        Facebook = facebook;
    }

    public String getInstagra() {
        return Instagra;
    }

    public void setInstagra(String instagra) {
        Instagra = instagra;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String direccion) {
        Direccion = direccion;
    }
}
