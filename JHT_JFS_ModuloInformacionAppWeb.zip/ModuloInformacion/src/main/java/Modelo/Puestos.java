package Modelo;

import java.io.Serializable;

public class Puestos implements Serializable {
    private int ID;
    private String Puesto;

    public Puestos(){

    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getPuesto() {
        return Puesto;
    }

    public void setPuesto(String puesto) {
        Puesto = puesto;
    }
}
