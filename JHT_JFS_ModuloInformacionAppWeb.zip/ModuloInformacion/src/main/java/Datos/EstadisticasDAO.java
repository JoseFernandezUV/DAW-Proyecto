package Datos;

import Modelo.Estadisticas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EstadisticasDAO {
    private static final Logger LOGGER = Logger.getLogger(EstadisticasDAO.class.getName());
    private Conexion conexion = new Conexion();

    public List<Estadisticas> getAllEstadisticas() {
        List<Estadisticas> estadisticasList = new ArrayList<>();
        String sql = "SELECT Areas.Area, Niveles.Nivel, Lugar, Fecha, Datos, Descripcion " +
                "FROM Estadisticas " +
                "JOIN Areas ON Estadisticas.FKArea = Areas.ID " +
                "JOIN Niveles ON Estadisticas.FKNivel = Niveles.ID";
        try (Connection con = conexion.establecerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {


            if (con != null) {
                LOGGER.info("Conexión a la base de datos establecida.");
            } else {
                LOGGER.severe("Error al establecer la conexión a la base de datos.");
            }


            LOGGER.info("Ejecutando consulta: " + sql);

            while (rs.next()) {
                Estadisticas estadisticas = new Estadisticas();
                estadisticas.setArea(rs.getString("Area"));
                estadisticas.setNivel(rs.getString("Nivel"));
                estadisticas.setLugar(rs.getString("Lugar"));
                estadisticas.setFecha(rs.getDate("Fecha"));
                estadisticas.setDatos(rs.getFloat("Datos"));
                estadisticas.setDescripcion(rs.getString("Descripcion"));
                estadisticasList.add(estadisticas);
                LOGGER.info("Registro recuperado: " + estadisticas.getLugar());
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al obtener estadísticas", e);
        }
        return estadisticasList;
    }
}
