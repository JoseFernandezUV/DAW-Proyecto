package Datos;

import Modelo.Campañas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CampañaDAO {
    private static final Logger LOGGER = Logger.getLogger(CampañaDAO.class.getName());
    private Conexion conexion = new Conexion();

    public List<Campañas> getAllCampañas() {
        List<Campañas> campañasList = new ArrayList<>();
        String sql = "SELECT Campañas.Nombre, Campañas.Descripcion, Areas.Area, Niveles.Nivel " +
                "FROM Campañas " +
                "JOIN Niveles ON Campañas.NivelFK = Niveles.ID " +
                "JOIN Areas ON Campañas.AreaFK = Areas.ID";
        try (Connection con = conexion.establecerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            // Mensajes de advertencias
            if (con != null) {
                LOGGER.info("Conexión a la base de datos establecida.");
            } else {
                LOGGER.severe("Error al establecer la conexión a la base de datos.");
            }

            // verifica que funcione la consulta
            LOGGER.info("Ejecutando consulta: " + sql);

            while (rs.next()) {
                Campañas campañas = new Campañas();
                campañas.setNombre(rs.getString("Nombre"));
                campañas.setDescripcion(rs.getString("Descripcion"));
                campañas.setArea(rs.getString("Area"));
                campañas.setNivel(rs.getString("Nivel"));
                campañasList.add(campañas);
                LOGGER.info("Registro recuperado: " + campañas.getNombre());
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al obtener campañas", e);
        }
        return campañasList;
    }
}
