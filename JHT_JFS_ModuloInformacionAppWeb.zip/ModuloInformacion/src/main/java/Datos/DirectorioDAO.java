package Datos;

import Modelo.Directorio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DirectorioDAO {
    private static final Logger LOGGER = Logger.getLogger(DirectorioDAO.class.getName());
    private Conexion conexion = new Conexion();

    public List<Directorio> getAllDirectorio() {
        List<Directorio> directorioList = new ArrayList<>();
        String sql = "SELECT Directorio.Nombre, Directorio.Telefono, Directorio.Correo, Directorio.Ubicacion, Puestos.Puesto " +
                "FROM Directorio " +
                "JOIN Puestos ON Directorio.FKPuesto = Puestos.ID";
        try (Connection con = conexion.establecerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {


            if (con != null) {
                LOGGER.info("Conexión a la base de datos establecida.");
            } else {
                LOGGER.severe("Error al establecer la conexión a la base de datos.");
            }


            LOGGER.info("Ejecutando consulta: " + sql);

            while (rs.next()) {
                Directorio directorio = new Directorio();
                directorio.setNombre(rs.getString("Nombre"));
                directorio.setTelefono(rs.getString("Telefono"));
                directorio.setCorreo(rs.getString("Correo"));
                directorio.setUbicacion(rs.getString("Ubicacion"));
                directorio.setPuesto(rs.getString("Puesto")); // Asegúrate de agregar este campo en la clase Directorio
                directorioList.add(directorio);
                LOGGER.info("Registro recuperado: " + directorio.getNombre());
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al obtener directorio", e);
        }
        return directorioList;
    }
}
